CREATE TABLE tblMember2(
 id CHAR(10) PRIMARY KEY,
 pwd CHAR(10) NOT null
);